

export class CreateClientDto {
    phone_number: string;
}
