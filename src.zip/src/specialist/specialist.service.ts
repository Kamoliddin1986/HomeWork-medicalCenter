import { OtpService } from './../otp/otp.service';
import { OtpModule } from './../otp/otp.module';
import { BadRequestException, Injectable } from '@nestjs/common';
import { AuthSpecialistDto } from './dto/auth-specialist.dto';
import { UpdateSpecialistDto } from './dto/update-specialist.dto';
import { Specialist, SpecialistDocument } from './schemas/specialist.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as otpGenerator from 'otp-generator'
import { AddMinutesToDate } from '../helpers/addMinutes';
import { Otp } from '../otp/schemas/otp.schema';
import { decode, encode } from '../helpers/crypto';
import { VerifyOtpDto } from '../otp/dto/verifyOtp.dto';
// import { OtpService } from '../otp/otp.service';

@Injectable()
export class SpecialistService {

  constructor(@InjectModel(Specialist.name) private specialistModel: Model<SpecialistDocument>,
 private readonly otpService: OtpService){}
  
  
  async auth(authSpecialistDto: AuthSpecialistDto) {
    const phone_number = authSpecialistDto.phone_number
    const otp = otpGenerator.generate(4, {
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false
    });

    const now = new Date()
    const expiretion_time = AddMinutesToDate(now,5)
    // console.log(expiretion_time);
    
    const newOtp = await this.otpService.create({
      otp,
      expiretion_time
    })


    const details = {
      timestamp: now,
      check: phone_number,
      success: true,
      message: "Otp send to user",
      otp_id: newOtp._id
    }

    const encoded = await encode(JSON.stringify(details));
    return {status: "Success", Details: encoded}
  }


  async verifyOtp(verifyOtpDto: VerifyOtpDto){
    const {verification_key,check, otp} = verifyOtpDto

    const currentDate = Date.now();
    const decod = await decode(verification_key);
    const obj = JSON.parse(decod);
    const phoneN_obj = obj.check;
    if(phoneN_obj != check) {
      throw new BadRequestException('Otp bu raqamga yuborilmagan')
    }

    const result = await this.otpService.findOneById(obj.otp_id)
  }

  findAll() {
    return `This action returns all specialist`;
  }

  findOne(id: number) {
    return `This action returns a #${id} specialist`;
  }

  update(id: number, updateSpecialistDto: UpdateSpecialistDto) {
    return `This action updates a #${id} specialist`;
  }

  remove(id: number) {
    return `This action removes a #${id} specialist`;
  }
}
