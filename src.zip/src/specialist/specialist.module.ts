import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { SpecialistService } from './specialist.service';
import { SpecialistController } from './specialist.controller';
import { Specialist, SpecialistSchema } from './schemas/specialist.schema';
import { Otp, OtpSchema } from '../otp/schemas/otp.schema';
import { OtpModule } from '../otp/otp.module';

@Module({
  imports: [MongooseModule.forFeature([{name: Specialist.name, schema: SpecialistSchema},{name: Otp.name, schema: OtpSchema}]), OtpModule],
  controllers: [SpecialistController],
  providers: [SpecialistService]
})
export class SpecialistModule {}
