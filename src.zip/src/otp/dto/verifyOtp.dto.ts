export class VerifyOtpDto {
    check: string;
    verification_key: string;
    otp: string
}