export function AddMinutesToDate(date: Date, minutes: number) {
    return new Date(date.getTime() + minutes*60*1000);
}