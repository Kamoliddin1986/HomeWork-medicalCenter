export class CreateTokenDto {
    table_name: string;
    user_id: string;
    hashed_refresh_token: string;
}
