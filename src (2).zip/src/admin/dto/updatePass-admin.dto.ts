export class UpdatePassAdminDto {
    old_pass: string;
    new_pass: string;
    confirm_pass: string;
}