export class CreateAdminDto {
    admin_name: string;
    admin_phone_number: string;
    password: string;
}
