export class CreateOtpDto {
    otp: number;
    expiretion_time: Date
}
