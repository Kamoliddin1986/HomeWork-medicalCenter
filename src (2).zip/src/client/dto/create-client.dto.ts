

export class CreateClientDto {
    client_phone_number: string;
    otp_id: string
}
