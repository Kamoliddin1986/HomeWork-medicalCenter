export class AuthClientDto {
    phone_number: string;
}