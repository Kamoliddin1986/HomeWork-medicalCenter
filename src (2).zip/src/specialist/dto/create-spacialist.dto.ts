export class CreateSpecialistDto {
    spec_phone_number: string;
    otp_id: string
}
