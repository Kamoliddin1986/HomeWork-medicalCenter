export class AuthSpecialistDto {
    phone_number: string;
}
